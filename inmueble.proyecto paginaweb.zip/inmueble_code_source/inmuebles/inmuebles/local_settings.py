DEBUG=True
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'USER': 'postgres',
        'NAME': 'postgres',
        'PASSWORD': 'VaxiDrez2025$',
        'HOST': 'localhost'
    }
}