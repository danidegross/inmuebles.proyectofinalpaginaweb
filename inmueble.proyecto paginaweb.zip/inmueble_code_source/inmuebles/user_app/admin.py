from django.contrib import admin

from user_app.models import Account

# Register your models here.
admin.site.register(Account)
